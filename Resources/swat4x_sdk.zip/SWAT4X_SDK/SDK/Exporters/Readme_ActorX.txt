
Please Note:

SWAT 4 uses a modified version of the ActorX animation and skeletal mesh exporting tool that differs from the version used by other Unreal Engine-based titles. 

If you attempt to use a different version of ActorX then your animations and skeletal meshes may not work in SWAT 4.

